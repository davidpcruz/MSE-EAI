package eai.msejdf.utils;

public final class XMLConstants
{

	/**
	 * File Encoding used on the XML files
	 */
	final static String FILE_ENCODING = "UTF8";	
}

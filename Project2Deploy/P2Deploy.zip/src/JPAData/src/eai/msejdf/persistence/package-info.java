/**
 * 
 */
/**
 * @author dcruz
 *
 */
package eai.msejdf.persistence;
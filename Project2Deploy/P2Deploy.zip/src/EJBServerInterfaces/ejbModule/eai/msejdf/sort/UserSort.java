package eai.msejdf.sort;

/**
 * The Enum UserSort that defines the order by clauses.
 */
public enum UserSort
{
	NONE, BIRTHDAY_ASC, BIRTHDAY_DESC, NAME_ASC, NAME_DESC 
}

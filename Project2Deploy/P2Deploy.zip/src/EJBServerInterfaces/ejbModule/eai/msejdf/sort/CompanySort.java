package eai.msejdf.sort;

/**
 * The Enum CompanySort that defines the order by clauses.
 */
public enum CompanySort
{
	NONE, NAME_ASC, NAME_DESC 
}

-- Creates a sample user on the system
INSERT INTO eaiproj2.user (name, username, password ) VALUES('user', 'user', 'user' );
-- Creates a administrative user on the system
INSERT INTO eaiproj2.backofficeuser (username, password ) VALUES('admin','admin' );


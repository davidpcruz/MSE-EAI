package eai.msejdf.security.credentials;


public class AdminCredentials extends Credentials {

	private static final long serialVersionUID = 1L;

	public AdminCredentials() {
		super(Credentials.ADMIN_CREDENTIAL);
	}
}

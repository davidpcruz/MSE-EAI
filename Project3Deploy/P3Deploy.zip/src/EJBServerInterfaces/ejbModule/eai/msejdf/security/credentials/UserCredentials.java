package eai.msejdf.security.credentials;

public class UserCredentials extends Credentials {
	private static final long serialVersionUID = 1L;
	
	public UserCredentials() {
		super(Credentials.USER_CREDENTIAL);
	}
}

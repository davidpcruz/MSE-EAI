/**
 * 
 */
/**
 * @author dcruz
 *
 */
package eai.msejdf.jms;